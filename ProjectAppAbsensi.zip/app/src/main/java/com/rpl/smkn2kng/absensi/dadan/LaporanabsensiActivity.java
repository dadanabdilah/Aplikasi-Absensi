package com.rpl.smkn2kng.absensi.dadan;

import androidx.appcompat.app.AppCompatActivity;
import androidx.annotation.*;
import androidx.appcompat.widget.Toolbar;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import com.google.android.material.appbar.AppBarLayout;
import android.app.*;
import android.os.*;
import android.view.*;
import android.view.View.*;
import android.widget.*;
import android.content.*;
import android.content.res.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.text.*;
import android.text.style.*;
import android.util.*;
import android.webkit.*;
import android.animation.*;
import android.view.animation.*;
import java.util.*;
import java.util.regex.*;
import java.text.*;
import org.json.*;
import java.util.HashMap;
import java.util.ArrayList;
import android.widget.LinearLayout;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Spinner;
import android.widget.ArrayAdapter;
import android.content.Intent;
import android.net.Uri;
import android.app.Activity;
import android.content.SharedPreferences;
import android.app.AlertDialog;
import android.content.DialogInterface;
import java.util.Calendar;
import java.text.SimpleDateFormat;
import android.view.View;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.DialogFragment;
import androidx.core.content.ContextCompat;
import androidx.core.app.ActivityCompat;
import android.Manifest;
import android.content.pm.PackageManager;


public class LaporanabsensiActivity extends  AppCompatActivity  { 
	
	
	private Toolbar _toolbar;
	private AppBarLayout _app_bar;
	private CoordinatorLayout _coordinator;
	private String imagename = "";
	private HashMap<String, Object> postdata = new HashMap<>();
	private double jml = 0;
	private double awal = 0;
	
	private ArrayList<String> listwaktuabsen = new ArrayList<>();
	private ArrayList<String> liststrkelas = new ArrayList<>();
	private ArrayList<HashMap<String, Object>> listmapkelas = new ArrayList<>();
	private ArrayList<String> listbulan = new ArrayList<>();
	private ArrayList<String> listtahun = new ArrayList<>();
	
	private LinearLayout linear1;
	private LinearLayout linear2;
	private LinearLayout linear3;
	private LinearLayout linear4;
	private LinearLayout linear6;
	private Button button1;
	private TextView textview1;
	private Spinner spinner1;
	private TextView textview2;
	private Spinner spinner2;
	private Spinner spinner3;
	private TextView textview3;
	private Spinner spinner4;
	
	private Intent intent = new Intent();
	private SharedPreferences fileconfig;
	private RequestNetwork reqnetw;
	private RequestNetwork.RequestListener _reqnetw_request_listener;
	private AlertDialog.Builder dialog;
	private Calendar calendar = Calendar.getInstance();
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.laporanabsensi);
		initialize(_savedInstanceState);
		if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_DENIED
		|| ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_DENIED) {
			ActivityCompat.requestPermissions(this, new String[] {Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE}, 1000);
		}
		else {
			initializeLogic();
		}
	}
	@Override
	public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
		super.onRequestPermissionsResult(requestCode, permissions, grantResults);
		if (requestCode == 1000) {
			initializeLogic();
		}
	}
	
	private void initialize(Bundle _savedInstanceState) {
		
		_app_bar = (AppBarLayout) findViewById(R.id._app_bar);
		_coordinator = (CoordinatorLayout) findViewById(R.id._coordinator);
		_toolbar = (Toolbar) findViewById(R.id._toolbar);
		setSupportActionBar(_toolbar);
		getSupportActionBar().setDisplayHomeAsUpEnabled(true);
		getSupportActionBar().setHomeButtonEnabled(true);
		_toolbar.setNavigationOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _v) {
				onBackPressed();
			}
		});
		linear1 = (LinearLayout) findViewById(R.id.linear1);
		linear2 = (LinearLayout) findViewById(R.id.linear2);
		linear3 = (LinearLayout) findViewById(R.id.linear3);
		linear4 = (LinearLayout) findViewById(R.id.linear4);
		linear6 = (LinearLayout) findViewById(R.id.linear6);
		button1 = (Button) findViewById(R.id.button1);
		textview1 = (TextView) findViewById(R.id.textview1);
		spinner1 = (Spinner) findViewById(R.id.spinner1);
		textview2 = (TextView) findViewById(R.id.textview2);
		spinner2 = (Spinner) findViewById(R.id.spinner2);
		spinner3 = (Spinner) findViewById(R.id.spinner3);
		textview3 = (TextView) findViewById(R.id.textview3);
		spinner4 = (Spinner) findViewById(R.id.spinner4);
		fileconfig = getSharedPreferences("fileconfig", Activity.MODE_PRIVATE);
		reqnetw = new RequestNetwork(this);
		dialog = new AlertDialog.Builder(this);
		
		button1.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				dialog.setTitle("Download Laporan");
				dialog.setMessage("Pilih jenis file yang akan didownload.");
				dialog.setPositiveButton("PDF", new DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface _dialog, int _which) {
						intent.setAction(Intent.ACTION_VIEW);
						intent.setData(Uri.parse(fileconfig.getString("server", "").concat("laporan".concat("/".concat("Admin".concat("/".concat("pdf".concat("/".concat(String.valueOf((long)(spinner1.getSelectedItemPosition() + 1)).concat("/".concat(listwaktuabsen.get((int)(spinner4.getSelectedItemPosition())).concat("/".concat(listbulan.get((int)(spinner2.getSelectedItemPosition())).concat("/".concat(listtahun.get((int)(spinner3.getSelectedItemPosition())))))))))))))))));
						startActivity(intent);
					}
				});
				dialog.setNegativeButton("EXCEL", new DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface _dialog, int _which) {
						intent.setAction(Intent.ACTION_VIEW);
						intent.setData(Uri.parse(fileconfig.getString("server", "").concat("laporan".concat("/".concat("Admin".concat("/".concat("excel".concat("/".concat(String.valueOf((long)(spinner1.getSelectedItemPosition() + 1)).concat("/".concat(listwaktuabsen.get((int)(spinner4.getSelectedItemPosition())).concat("/".concat(listbulan.get((int)(spinner2.getSelectedItemPosition())).concat("/".concat(listtahun.get((int)(spinner3.getSelectedItemPosition())))))))))))))))));
						startActivity(intent);
					}
				});
				dialog.create().show();
			}
		});
		
		_reqnetw_request_listener = new RequestNetwork.RequestListener() {
			@Override
			public void onResponse(String _param1, String _param2, HashMap<String, Object> _param3) {
				final String _tag = _param1;
				final String _response = _param2;
				final HashMap<String, Object> _responseHeaders = _param3;
				if (_tag.equals("GETKELAS")) {
					if (_response.equals("")) {
						SketchwareUtil.showMessage(getApplicationContext(), _response);
					}
					else {
						listmapkelas = new Gson().fromJson(_response, new TypeToken<ArrayList<HashMap<String, Object>>>(){}.getType());
						jml = listmapkelas.size();
						awal = 0;
						for(int _repeat23 = 0; _repeat23 < (int)(jml); _repeat23++) {
							liststrkelas.add(listmapkelas.get((int)awal).get("kelas").toString());
							awal++;
						}
						spinner1.setAdapter(new ArrayAdapter<String>(getBaseContext(), android.R.layout.simple_spinner_dropdown_item, liststrkelas));
						((ArrayAdapter)spinner1.getAdapter()).notifyDataSetChanged();
					}
				}
			}
			
			@Override
			public void onErrorResponse(String _param1, String _param2) {
				final String _tag = _param1;
				final String _message = _param2;
				SketchwareUtil.showMessage(getApplicationContext(), _message);
			}
		};
	}
	
	private void initializeLogic() {
		setTitle("Laporan");
		listbulan.add("All");
		listwaktuabsen.add("All");
		listwaktuabsen.add("Pagi");
		listwaktuabsen.add("Sore");
		spinner4.setAdapter(new ArrayAdapter<String>(getBaseContext(), android.R.layout.simple_spinner_dropdown_item, listwaktuabsen));
		((ArrayAdapter)spinner4.getAdapter()).notifyDataSetChanged();
		reqnetw.startRequestNetwork(RequestNetworkController.POST, fileconfig.getString("server", "").concat("tampil_kelas"), "GETKELAS", _reqnetw_request_listener);
		jml = 12;
		awal = 1;
		for(int _repeat73 = 0; _repeat73 < (int)(jml); _repeat73++) {
			listbulan.add(String.valueOf((long)(awal)));
			awal++;
		}
		spinner2.setAdapter(new ArrayAdapter<String>(getBaseContext(), android.R.layout.simple_spinner_dropdown_item, listbulan));
		((ArrayAdapter)spinner2.getAdapter()).notifyDataSetChanged();
		jml = 5;
		awal = Double.parseDouble(new SimpleDateFormat("y").format(calendar.getTime()));
		for(int _repeat87 = 0; _repeat87 < (int)(jml); _repeat87++) {
			listtahun.add(String.valueOf((long)(awal)));
			awal--;
		}
		spinner3.setAdapter(new ArrayAdapter<String>(getBaseContext(), android.R.layout.simple_spinner_dropdown_item, listtahun));
		((ArrayAdapter)spinner3.getAdapter()).notifyDataSetChanged();
		
		linear2.setElevation((float)20);
		textview1.setTextSize((int)15);
		textview2.setTextSize((int)15);
		textview3.setTextSize((int)15);
	}
	
	@Override
	protected void onActivityResult(int _requestCode, int _resultCode, Intent _data) {
		
		super.onActivityResult(_requestCode, _resultCode, _data);
		
		switch (_requestCode) {
			
			default:
			break;
		}
	}
	
	@Override
	public void onBackPressed() {
		intent.setClass(getApplicationContext(), AdminActivity.class);
		startActivity(intent);
		finish();
	}
	public void _Downloader (final String _url, final String _path) {
		FileUtil.makeDir(FileUtil.getPackageDataDir(getApplicationContext()));
		
		android.net.ConnectivityManager connMgr = (android.net.ConnectivityManager)getSystemService(Context.CONNECTIVITY_SERVICE);
		android.net.NetworkInfo networkInfo = connMgr.getActiveNetworkInfo();
		if (networkInfo != null && networkInfo.isConnected()) {
			
			
			final String urlDownload = _url;
			
			DownloadManager.Request request = new DownloadManager.Request(Uri.parse(urlDownload));
			
			final String fileName = URLUtil.guessFileName(urlDownload, null, null);
			
			request.setDescription("Download Processing...");
			
			request.setTitle(fileName);
			
			request.allowScanningByMediaScanner();
			
			request.setDestinationInExternalPublicDir(_path, fileName);
			
			final DownloadManager manager = (DownloadManager) getSystemService(Context.DOWNLOAD_SERVICE);
			
			final long downloadId = manager.enqueue(request);
			
			final ProgressDialog prog = new ProgressDialog(this);
			prog.setMax(100);
			prog.setIndeterminate(true);
			prog.setCancelable(false);
			prog.setCanceledOnTouchOutside(false);
			prog.setTitle("Start Downloading");
			
			new Thread(new Runnable() {
				@Override
				public void run() {
					
					boolean downloading = true;
					
					while (downloading) {
						
						DownloadManager.Query q = new DownloadManager.Query();
						
						q.setFilterById(downloadId);
						
						android.database.Cursor cursor = manager.query(q);
						
						cursor.moveToFirst();
						
						int bytes_downloaded = cursor.getInt(cursor .getColumnIndex(DownloadManager.COLUMN_BYTES_DOWNLOADED_SO_FAR));
						
						int bytes_total = cursor.getInt(cursor.getColumnIndex(DownloadManager.COLUMN_TOTAL_SIZE_BYTES));
						
						if (cursor.getInt(cursor.getColumnIndex(DownloadManager.COLUMN_STATUS)) == DownloadManager.STATUS_SUCCESSFUL) {
							
							downloading = false;
							
						}
						
						final int dl_progress = (int) ((bytes_downloaded * 100l) / bytes_total);
						
						runOnUiThread(new Runnable() {
							@Override
							public void run() {
								
								prog.setTitle("Download Processing.");
								prog.setMessage("Start " + dl_progress + "/100 ");
								prog.show();
								if (dl_progress == 100) {
									prog.dismiss();
									showMessage("Download Complete.");
								}
							} });
					} } }).start();
			
		} else {
			showMessage("Check internet connection...");
		}
	}
	
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input){
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels(){
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels(){
		return getResources().getDisplayMetrics().heightPixels;
	}
	
}
