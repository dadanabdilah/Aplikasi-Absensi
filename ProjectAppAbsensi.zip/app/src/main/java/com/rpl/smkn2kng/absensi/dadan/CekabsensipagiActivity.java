package com.rpl.smkn2kng.absensi.dadan;

import androidx.appcompat.app.AppCompatActivity;
import androidx.annotation.*;
import androidx.appcompat.widget.Toolbar;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import com.google.android.material.appbar.AppBarLayout;
import android.app.*;
import android.os.*;
import android.view.*;
import android.view.View.*;
import android.widget.*;
import android.content.*;
import android.content.res.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.text.*;
import android.text.style.*;
import android.util.*;
import android.webkit.*;
import android.animation.*;
import android.view.animation.*;
import java.util.*;
import java.util.regex.*;
import java.text.*;
import org.json.*;
import java.util.ArrayList;
import java.util.HashMap;
import android.widget.LinearLayout;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.TextView;
import android.content.Intent;
import android.net.Uri;
import android.app.Activity;
import android.content.SharedPreferences;
import android.view.View;
import android.widget.AdapterView;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.DialogFragment;


public class CekabsensipagiActivity extends  AppCompatActivity  { 
	
	
	private Toolbar _toolbar;
	private AppBarLayout _app_bar;
	private CoordinatorLayout _coordinator;
	
	private ArrayList<HashMap<String, Object>> listmaphistori = new ArrayList<>();
	private ArrayList<HashMap<String, Object>> listmapdata = new ArrayList<>();
	
	private LinearLayout linear1;
	private LinearLayout linear2;
	private LinearLayout linear3;
	private LinearLayout linear4;
	private EditText edittext1;
	private ListView listview1;
	private EditText edittext2;
	private ListView listview2;
	private TextView textview1;
	private TextView textview2;
	
	private Intent intent = new Intent();
	private SharedPreferences fileconfig;
	private RequestNetwork reqnetw;
	private RequestNetwork.RequestListener _reqnetw_request_listener;
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.cekabsensipagi);
		initialize(_savedInstanceState);
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		
		_app_bar = (AppBarLayout) findViewById(R.id._app_bar);
		_coordinator = (CoordinatorLayout) findViewById(R.id._coordinator);
		_toolbar = (Toolbar) findViewById(R.id._toolbar);
		setSupportActionBar(_toolbar);
		getSupportActionBar().setDisplayHomeAsUpEnabled(true);
		getSupportActionBar().setHomeButtonEnabled(true);
		_toolbar.setNavigationOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _v) {
				onBackPressed();
			}
		});
		linear1 = (LinearLayout) findViewById(R.id.linear1);
		linear2 = (LinearLayout) findViewById(R.id.linear2);
		linear3 = (LinearLayout) findViewById(R.id.linear3);
		linear4 = (LinearLayout) findViewById(R.id.linear4);
		edittext1 = (EditText) findViewById(R.id.edittext1);
		listview1 = (ListView) findViewById(R.id.listview1);
		edittext2 = (EditText) findViewById(R.id.edittext2);
		listview2 = (ListView) findViewById(R.id.listview2);
		textview1 = (TextView) findViewById(R.id.textview1);
		textview2 = (TextView) findViewById(R.id.textview2);
		fileconfig = getSharedPreferences("fileconfig", Activity.MODE_PRIVATE);
		reqnetw = new RequestNetwork(this);
		
		listview1.setOnItemClickListener(new AdapterView.OnItemClickListener() {
			@Override
			public void onItemClick(AdapterView<?> _param1, View _param2, int _param3, long _param4) {
				final int _position = _param3;
				fileconfig.edit().putString("waktu_absensi", "Pagi").commit();
				intent.putExtra("nis", listmapdata.get((int)_position).get("nis").toString());
				intent.putExtra("nama_siswa", listmapdata.get((int)_position).get("nama_siswa").toString());
				intent.setClass(getApplicationContext(), IsiabsensiActivity.class);
				startActivity(intent);
				finish();
			}
		});
		
		textview1.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				
				
				linear3.setVisibility(View.GONE);
				linear2.setVisibility(View.VISIBLE);
			}
		});
		
		textview2.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				
				
				linear2.setVisibility(View.GONE);
				linear3.setVisibility(View.VISIBLE);
			}
		});
		
		_reqnetw_request_listener = new RequestNetwork.RequestListener() {
			@Override
			public void onResponse(String _param1, String _param2, HashMap<String, Object> _param3) {
				final String _tag = _param1;
				final String _response = _param2;
				final HashMap<String, Object> _responseHeaders = _param3;
				if (_tag.equals("GETHISTORI")) {
					if (_response.equals("")) {
						SketchwareUtil.showMessage(getApplicationContext(), "Tidak ada data.");
					}
					else {
						listmaphistori = new Gson().fromJson(_response, new TypeToken<ArrayList<HashMap<String, Object>>>(){}.getType());
						listview2.setAdapter(new Listview2Adapter(listmaphistori));
						((BaseAdapter)listview2.getAdapter()).notifyDataSetChanged();
					}
				}
				if (_tag.equals("GETDATA")) {
					if (_response.equals("")) {
						SketchwareUtil.showMessage(getApplicationContext(), "Tidak ada data.");
					}
					else {
						listmapdata = new Gson().fromJson(_response, new TypeToken<ArrayList<HashMap<String, Object>>>(){}.getType());
						listview1.setAdapter(new Listview1Adapter(listmapdata));
						((BaseAdapter)listview1.getAdapter()).notifyDataSetChanged();
					}
				}
			}
			
			@Override
			public void onErrorResponse(String _param1, String _param2) {
				final String _tag = _param1;
				final String _message = _param2;
				SketchwareUtil.showMessage(getApplicationContext(), _message);
			}
		};
	}
	
	private void initializeLogic() {
		setTitle("Cek Absensi Pagi");
		
		linear3.setVisibility(View.GONE);
	}
	
	@Override
	protected void onActivityResult(int _requestCode, int _resultCode, Intent _data) {
		
		super.onActivityResult(_requestCode, _resultCode, _data);
		
		switch (_requestCode) {
			
			default:
			break;
		}
	}
	
	@Override
	public void onBackPressed() {
		if (fileconfig.getString("level", "").equals("Sekertaris")) {
			intent.setClass(getApplicationContext(), SekertarisActivity.class);
			startActivity(intent);
			finish();
		}
		else {
			intent.setClass(getApplicationContext(), PiketActivity.class);
			startActivity(intent);
			finish();
		}
	}
	
	@Override
	public void onStart() {
		super.onStart();
		if (fileconfig.getString("level", "").equals("Sekertaris")) {
			reqnetw.startRequestNetwork(RequestNetworkController.POST, fileconfig.getString("server", "").concat("histori_absensi".concat("/".concat("Pagi".concat("/".concat(fileconfig.getString("id_kelas", "")))))), "GETHISTORI", _reqnetw_request_listener);
			reqnetw.startRequestNetwork(RequestNetworkController.POST, fileconfig.getString("server", "").concat("tampil_absensi".concat("/".concat("Pagi".concat("/".concat(fileconfig.getString("id_kelas", "")))))), "GETDATA", _reqnetw_request_listener);
		}
		else {
			reqnetw.startRequestNetwork(RequestNetworkController.POST, fileconfig.getString("server", "").concat("histori_absensi".concat("/".concat("Pagi"))), "GETHISTORI", _reqnetw_request_listener);
			reqnetw.startRequestNetwork(RequestNetworkController.POST, fileconfig.getString("server", "").concat("tampil_absensi".concat("/".concat("Pagi"))), "GETDATA", _reqnetw_request_listener);
		}
	}
	public class Listview1Adapter extends BaseAdapter {
		ArrayList<HashMap<String, Object>> _data;
		public Listview1Adapter(ArrayList<HashMap<String, Object>> _arr) {
			_data = _arr;
		}
		
		@Override
		public int getCount() {
			return _data.size();
		}
		
		@Override
		public HashMap<String, Object> getItem(int _index) {
			return _data.get(_index);
		}
		
		@Override
		public long getItemId(int _index) {
			return _index;
		}
		@Override
		public View getView(final int _position, View _v, ViewGroup _container) {
			LayoutInflater _inflater = (LayoutInflater)getBaseContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
			View _view = _v;
			if (_view == null) {
				_view = _inflater.inflate(R.layout.listdatapagi, null);
			}
			
			final LinearLayout linear1 = (LinearLayout) _view.findViewById(R.id.linear1);
			final LinearLayout linear2 = (LinearLayout) _view.findViewById(R.id.linear2);
			final LinearLayout linear3 = (LinearLayout) _view.findViewById(R.id.linear3);
			final LinearLayout linear4 = (LinearLayout) _view.findViewById(R.id.linear4);
			final TextView textview1 = (TextView) _view.findViewById(R.id.textview1);
			final TextView textview2 = (TextView) _view.findViewById(R.id.textview2);
			final TextView textview3 = (TextView) _view.findViewById(R.id.textview3);
			final TextView textview4 = (TextView) _view.findViewById(R.id.textview4);
			final TextView textview5 = (TextView) _view.findViewById(R.id.textview5);
			final TextView textview6 = (TextView) _view.findViewById(R.id.textview6);
			final TextView textview7 = (TextView) _view.findViewById(R.id.textview7);
			final TextView textview8 = (TextView) _view.findViewById(R.id.textview8);
			
			textview2.setText(listmapdata.get((int)_position).get("nis").toString());
			textview4.setText(listmapdata.get((int)_position).get("nama_siswa").toString());
			textview6.setText(listmapdata.get((int)_position).get("kelas").toString());
			textview8.setText(listmapdata.get((int)_position).get("no_hp").toString());
			
			return _view;
		}
	}
	
	public class Listview2Adapter extends BaseAdapter {
		ArrayList<HashMap<String, Object>> _data;
		public Listview2Adapter(ArrayList<HashMap<String, Object>> _arr) {
			_data = _arr;
		}
		
		@Override
		public int getCount() {
			return _data.size();
		}
		
		@Override
		public HashMap<String, Object> getItem(int _index) {
			return _data.get(_index);
		}
		
		@Override
		public long getItemId(int _index) {
			return _index;
		}
		@Override
		public View getView(final int _position, View _v, ViewGroup _container) {
			LayoutInflater _inflater = (LayoutInflater)getBaseContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
			View _view = _v;
			if (_view == null) {
				_view = _inflater.inflate(R.layout.listhistoriabsen, null);
			}
			
			final LinearLayout linear1 = (LinearLayout) _view.findViewById(R.id.linear1);
			final LinearLayout linear2 = (LinearLayout) _view.findViewById(R.id.linear2);
			final LinearLayout linear3 = (LinearLayout) _view.findViewById(R.id.linear3);
			final LinearLayout linear4 = (LinearLayout) _view.findViewById(R.id.linear4);
			final LinearLayout linear5 = (LinearLayout) _view.findViewById(R.id.linear5);
			final LinearLayout linear6 = (LinearLayout) _view.findViewById(R.id.linear6);
			final LinearLayout linear7 = (LinearLayout) _view.findViewById(R.id.linear7);
			final TextView textview1 = (TextView) _view.findViewById(R.id.textview1);
			final TextView textview2 = (TextView) _view.findViewById(R.id.textview2);
			final TextView textview3 = (TextView) _view.findViewById(R.id.textview3);
			final TextView textview4 = (TextView) _view.findViewById(R.id.textview4);
			final TextView textview5 = (TextView) _view.findViewById(R.id.textview5);
			final TextView textview6 = (TextView) _view.findViewById(R.id.textview6);
			final TextView textview7 = (TextView) _view.findViewById(R.id.textview7);
			final TextView textview8 = (TextView) _view.findViewById(R.id.textview8);
			final TextView textview9 = (TextView) _view.findViewById(R.id.textview9);
			final TextView textview10 = (TextView) _view.findViewById(R.id.textview10);
			final TextView textview11 = (TextView) _view.findViewById(R.id.textview11);
			final TextView textview12 = (TextView) _view.findViewById(R.id.textview12);
			final TextView textview13 = (TextView) _view.findViewById(R.id.textview13);
			final TextView textview14 = (TextView) _view.findViewById(R.id.textview14);
			
			textview1.setText("Nomor Induk Siswa");
			textview3.setText("Nama Siswa");
			textview5.setText("Kelas");
			textview7.setText("Tanggal Absensi");
			textview9.setText("Kehadiran");
			textview11.setText("Keterangan");
			textview2.setText(listmaphistori.get((int)_position).get("nis").toString());
			textview4.setText(listmaphistori.get((int)_position).get("nama_siswa").toString());
			textview6.setText(listmaphistori.get((int)_position).get("kelas").toString());
			textview8.setText(listmaphistori.get((int)_position).get("tanggal_absensi").toString());
			textview10.setText(listmaphistori.get((int)_position).get("kehadiran").toString());
			textview12.setText(listmaphistori.get((int)_position).get("keterangan").toString());
			
			return _view;
		}
	}
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input){
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels(){
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels(){
		return getResources().getDisplayMetrics().heightPixels;
	}
	
}
