package com.rpl.smkn2kng.absensi.dadan;

import androidx.appcompat.app.AppCompatActivity;
import androidx.annotation.*;
import androidx.appcompat.widget.Toolbar;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import com.google.android.material.appbar.AppBarLayout;
import android.app.*;
import android.os.*;
import android.view.*;
import android.view.View.*;
import android.widget.*;
import android.content.*;
import android.content.res.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.text.*;
import android.text.style.*;
import android.util.*;
import android.webkit.*;
import android.animation.*;
import android.view.animation.*;
import java.util.*;
import java.util.regex.*;
import java.text.*;
import org.json.*;
import java.util.HashMap;
import java.util.ArrayList;
import android.widget.ScrollView;
import android.widget.LinearLayout;
import android.widget.EditText;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Spinner;
import android.widget.ArrayAdapter;
import android.content.Intent;
import android.net.Uri;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.app.Activity;
import android.content.SharedPreferences;
import android.view.View;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.DialogFragment;


public class TambahgurupiketActivity extends  AppCompatActivity  { 
	
	
	private Toolbar _toolbar;
	private AppBarLayout _app_bar;
	private CoordinatorLayout _coordinator;
	private HashMap<String, Object> mappostsdata = new HashMap<>();
	private HashMap<String, Object> map_jam1 = new HashMap<>();
	private double awal = 0;
	private double jml = 0;
	private double awal2 = 0;
	private double jml2 = 0;
	
	private ArrayList<String> strlisthari = new ArrayList<>();
	private ArrayList<String> strlist_jam1 = new ArrayList<>();
	private ArrayList<String> strlist_jam2 = new ArrayList<>();
	private ArrayList<HashMap<String, Object>> list_map_jam1 = new ArrayList<>();
	private ArrayList<HashMap<String, Object>> list_map_jam2 = new ArrayList<>();
	
	private ScrollView vscroll1;
	private LinearLayout linear1;
	private EditText edittext1;
	private EditText edittext2;
	private LinearLayout linear2;
	private LinearLayout linear3;
	private Button button1;
	private TextView textview1;
	private Spinner spinner1;
	private TextView textview2;
	private Spinner spinner2;
	private TextView textview3;
	private Spinner spinner3;
	
	private Intent intent = new Intent();
	private AlertDialog.Builder dialog;
	private RequestNetwork reqnetw;
	private RequestNetwork.RequestListener _reqnetw_request_listener;
	private SharedPreferences fileconfig;
	private RequestNetwork reqnetwjam1;
	private RequestNetwork.RequestListener _reqnetwjam1_request_listener;
	private RequestNetwork reqnetwjam2;
	private RequestNetwork.RequestListener _reqnetwjam2_request_listener;
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.tambahgurupiket);
		initialize(_savedInstanceState);
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		
		_app_bar = (AppBarLayout) findViewById(R.id._app_bar);
		_coordinator = (CoordinatorLayout) findViewById(R.id._coordinator);
		_toolbar = (Toolbar) findViewById(R.id._toolbar);
		setSupportActionBar(_toolbar);
		getSupportActionBar().setDisplayHomeAsUpEnabled(true);
		getSupportActionBar().setHomeButtonEnabled(true);
		_toolbar.setNavigationOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _v) {
				onBackPressed();
			}
		});
		vscroll1 = (ScrollView) findViewById(R.id.vscroll1);
		linear1 = (LinearLayout) findViewById(R.id.linear1);
		edittext1 = (EditText) findViewById(R.id.edittext1);
		edittext2 = (EditText) findViewById(R.id.edittext2);
		linear2 = (LinearLayout) findViewById(R.id.linear2);
		linear3 = (LinearLayout) findViewById(R.id.linear3);
		button1 = (Button) findViewById(R.id.button1);
		textview1 = (TextView) findViewById(R.id.textview1);
		spinner1 = (Spinner) findViewById(R.id.spinner1);
		textview2 = (TextView) findViewById(R.id.textview2);
		spinner2 = (Spinner) findViewById(R.id.spinner2);
		textview3 = (TextView) findViewById(R.id.textview3);
		spinner3 = (Spinner) findViewById(R.id.spinner3);
		dialog = new AlertDialog.Builder(this);
		reqnetw = new RequestNetwork(this);
		fileconfig = getSharedPreferences("fileconfig", Activity.MODE_PRIVATE);
		reqnetwjam1 = new RequestNetwork(this);
		reqnetwjam2 = new RequestNetwork(this);
		
		button1.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				mappostsdata = new HashMap<>();
				mappostsdata.put("nip", edittext1.getText().toString());
				mappostsdata.put("nama_guru", edittext2.getText().toString());
				mappostsdata.put("hari", strlisthari.get((int)(spinner1.getSelectedItemPosition())));
				mappostsdata.put("jam_piket1", strlist_jam1.get((int)(spinner2.getSelectedItemPosition())));
				mappostsdata.put("jam_piket2", strlist_jam2.get((int)(spinner3.getSelectedItemPosition())));
				dialog.setTitle("Tambah Data");
				dialog.setMessage("Simpan data ini?");
				dialog.setPositiveButton("Ya", new DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface _dialog, int _which) {
						reqnetw.setParams(mappostsdata, RequestNetworkController.REQUEST_PARAM);
						reqnetw.startRequestNetwork(RequestNetworkController.POST, fileconfig.getString("server", "").concat("tambah_guru_piket"), "SAVEDATA", _reqnetw_request_listener);
					}
				});
				dialog.setNegativeButton("Tidak", new DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface _dialog, int _which) {
						
					}
				});
				dialog.create().show();
			}
		});
		
		_reqnetw_request_listener = new RequestNetwork.RequestListener() {
			@Override
			public void onResponse(String _param1, String _param2, HashMap<String, Object> _param3) {
				final String _tag = _param1;
				final String _response = _param2;
				final HashMap<String, Object> _responseHeaders = _param3;
				SketchwareUtil.showMessage(getApplicationContext(), _response);
				intent.setClass(getApplicationContext(), KelolagurupiketActivity.class);
				startActivity(intent);
				finish();
			}
			
			@Override
			public void onErrorResponse(String _param1, String _param2) {
				final String _tag = _param1;
				final String _message = _param2;
				SketchwareUtil.showMessage(getApplicationContext(), _message);
				intent.setClass(getApplicationContext(), KelolagurupiketActivity.class);
				startActivity(intent);
				finish();
			}
		};
		
		_reqnetwjam1_request_listener = new RequestNetwork.RequestListener() {
			@Override
			public void onResponse(String _param1, String _param2, HashMap<String, Object> _param3) {
				final String _tag = _param1;
				final String _response = _param2;
				final HashMap<String, Object> _responseHeaders = _param3;
				if (_tag.equals("GETJAM1")) {
					if (_response.equals("")) {
						SketchwareUtil.showMessage(getApplicationContext(), _response);
					}
					else {
						list_map_jam1 = new Gson().fromJson(_response, new TypeToken<ArrayList<HashMap<String, Object>>>(){}.getType());
						jml = list_map_jam1.size();
						awal = 0;
						for(int _repeat42 = 0; _repeat42 < (int)(jml); _repeat42++) {
							strlist_jam1.add(list_map_jam1.get((int)awal).get("jam_piket").toString());
							awal++;
						}
						spinner2.setAdapter(new ArrayAdapter<String>(getBaseContext(), android.R.layout.simple_spinner_dropdown_item, strlist_jam1));
						((ArrayAdapter)spinner2.getAdapter()).notifyDataSetChanged();
					}
				}
			}
			
			@Override
			public void onErrorResponse(String _param1, String _param2) {
				final String _tag = _param1;
				final String _message = _param2;
				SketchwareUtil.showMessage(getApplicationContext(), _message);
			}
		};
		
		_reqnetwjam2_request_listener = new RequestNetwork.RequestListener() {
			@Override
			public void onResponse(String _param1, String _param2, HashMap<String, Object> _param3) {
				final String _tag = _param1;
				final String _response = _param2;
				final HashMap<String, Object> _responseHeaders = _param3;
				if (_tag.equals("GETJAM2")) {
					if (_response.equals("")) {
						SketchwareUtil.showMessage(getApplicationContext(), _response);
					}
					else {
						list_map_jam2 = new Gson().fromJson(_response, new TypeToken<ArrayList<HashMap<String, Object>>>(){}.getType());
						jml2 = list_map_jam2.size();
						awal2 = 0;
						for(int _repeat23 = 0; _repeat23 < (int)(jml2); _repeat23++) {
							strlist_jam2.add(list_map_jam2.get((int)awal2).get("jam_piket").toString());
							awal2++;
						}
						spinner3.setAdapter(new ArrayAdapter<String>(getBaseContext(), android.R.layout.simple_spinner_dropdown_item, strlist_jam2));
						((ArrayAdapter)spinner3.getAdapter()).notifyDataSetChanged();
					}
				}
			}
			
			@Override
			public void onErrorResponse(String _param1, String _param2) {
				final String _tag = _param1;
				final String _message = _param2;
				SketchwareUtil.showMessage(getApplicationContext(), _message);
			}
		};
	}
	
	private void initializeLogic() {
		setTitle("Tambah Guru Piket");
		reqnetwjam2.startRequestNetwork(RequestNetworkController.POST, fileconfig.getString("server", "").concat("tampil_jadwal_piket"), "GETJAM2", _reqnetwjam2_request_listener);
		strlisthari.add("Senin");
		strlisthari.add("Selasa");
		strlisthari.add("Rabu");
		strlisthari.add("Kamis");
		strlisthari.add("Jum'at");
		spinner1.setAdapter(new ArrayAdapter<String>(getBaseContext(), android.R.layout.simple_spinner_dropdown_item, strlisthari));
		((ArrayAdapter)spinner1.getAdapter()).notifyDataSetChanged();
	}
	
	@Override
	protected void onActivityResult(int _requestCode, int _resultCode, Intent _data) {
		
		super.onActivityResult(_requestCode, _resultCode, _data);
		
		switch (_requestCode) {
			
			default:
			break;
		}
	}
	
	@Override
	public void onBackPressed() {
		intent.setClass(getApplicationContext(), KelolagurupiketActivity.class);
		startActivity(intent);
		finish();
	}
	
	@Override
	public void onStart() {
		super.onStart();
		reqnetwjam1.startRequestNetwork(RequestNetworkController.POST, fileconfig.getString("server", "").concat("tampil_jadwal_piket"), "GETJAM1", _reqnetwjam1_request_listener);
	}
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input){
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels(){
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels(){
		return getResources().getDisplayMetrics().heightPixels;
	}
	
}
