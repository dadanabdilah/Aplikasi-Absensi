package com.rpl.smkn2kng.absensi.dadan;

import androidx.appcompat.app.AppCompatActivity;
import androidx.annotation.*;
import androidx.appcompat.widget.Toolbar;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import com.google.android.material.appbar.AppBarLayout;
import android.app.*;
import android.os.*;
import android.view.*;
import android.view.View.*;
import android.widget.*;
import android.content.*;
import android.content.res.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.text.*;
import android.text.style.*;
import android.util.*;
import android.webkit.*;
import android.animation.*;
import android.view.animation.*;
import java.util.*;
import java.util.regex.*;
import java.text.*;
import org.json.*;
import java.util.HashMap;
import java.util.ArrayList;
import android.widget.ScrollView;
import android.widget.LinearLayout;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Spinner;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.content.Intent;
import android.net.Uri;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.app.Activity;
import android.content.SharedPreferences;
import android.view.View;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.DialogFragment;


public class UpdateuserActivity extends  AppCompatActivity  { 
	
	
	private Toolbar _toolbar;
	private AppBarLayout _app_bar;
	private CoordinatorLayout _coordinator;
	private HashMap<String, Object> mapostdata = new HashMap<>();
	private double jml = 0;
	private double awal = 0;
	private HashMap<String, Object> maphapusdata = new HashMap<>();
	
	private ArrayList<String> strlevel = new ArrayList<>();
	private ArrayList<HashMap<String, Object>> listmaplevel = new ArrayList<>();
	
	private ScrollView vscroll1;
	private LinearLayout linear1;
	private EditText edittext1;
	private EditText edittext2;
	private LinearLayout linear3;
	private LinearLayout linear2;
	private TextView textview1;
	private Spinner spinner1;
	private Button button1;
	private Button button2;
	private Button button3;
	
	private Intent intent = new Intent();
	private RequestNetwork reqnetw;
	private RequestNetwork.RequestListener _reqnetw_request_listener;
	private AlertDialog.Builder dialog;
	private SharedPreferences fileconfig;
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.updateuser);
		initialize(_savedInstanceState);
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		
		_app_bar = (AppBarLayout) findViewById(R.id._app_bar);
		_coordinator = (CoordinatorLayout) findViewById(R.id._coordinator);
		_toolbar = (Toolbar) findViewById(R.id._toolbar);
		setSupportActionBar(_toolbar);
		getSupportActionBar().setDisplayHomeAsUpEnabled(true);
		getSupportActionBar().setHomeButtonEnabled(true);
		_toolbar.setNavigationOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _v) {
				onBackPressed();
			}
		});
		vscroll1 = (ScrollView) findViewById(R.id.vscroll1);
		linear1 = (LinearLayout) findViewById(R.id.linear1);
		edittext1 = (EditText) findViewById(R.id.edittext1);
		edittext2 = (EditText) findViewById(R.id.edittext2);
		linear3 = (LinearLayout) findViewById(R.id.linear3);
		linear2 = (LinearLayout) findViewById(R.id.linear2);
		textview1 = (TextView) findViewById(R.id.textview1);
		spinner1 = (Spinner) findViewById(R.id.spinner1);
		button1 = (Button) findViewById(R.id.button1);
		button2 = (Button) findViewById(R.id.button2);
		button3 = (Button) findViewById(R.id.button3);
		reqnetw = new RequestNetwork(this);
		dialog = new AlertDialog.Builder(this);
		fileconfig = getSharedPreferences("fileconfig", Activity.MODE_PRIVATE);
		
		button1.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				mapostdata = new HashMap<>();
				mapostdata.put("username", edittext1.getText().toString());
				mapostdata.put("nama_user", edittext2.getText().toString());
				mapostdata.put("id_level", String.valueOf((long)(spinner1.getSelectedItemPosition() + 1)));
				dialog.setTitle("Update Data");
				dialog.setMessage("Update data ini?");
				dialog.setPositiveButton("Ya", new DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface _dialog, int _which) {
						reqnetw.setParams(mapostdata, RequestNetworkController.REQUEST_PARAM);
						reqnetw.startRequestNetwork(RequestNetworkController.POST, fileconfig.getString("server", "").concat("update_user"), "UPDATE", _reqnetw_request_listener);
					}
				});
				dialog.setNegativeButton("Tidak", new DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface _dialog, int _which) {
						
					}
				});
				dialog.create().show();
			}
		});
		
		button2.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				maphapusdata = new HashMap<>();
				maphapusdata.put("username", edittext1.getText().toString());
				dialog.setTitle("Delete Data");
				dialog.setMessage("Hapus data user ini?");
				dialog.setPositiveButton("Ya", new DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface _dialog, int _which) {
						reqnetw.setParams(maphapusdata, RequestNetworkController.REQUEST_PARAM);
						reqnetw.startRequestNetwork(RequestNetworkController.POST, fileconfig.getString("server", "").concat("hapus_user"), "DELETE", _reqnetw_request_listener);
					}
				});
				dialog.setNegativeButton("Tidak", new DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface _dialog, int _which) {
						
					}
				});
				dialog.create().show();
			}
		});
		
		button3.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				intent.setClass(getApplicationContext(), KelolauserActivity.class);
				intent.putExtra("nama_user", getIntent().getStringExtra("nama_user"));
				intent.putExtra("server", getIntent().getStringExtra("server"));
				startActivity(intent);
				finish();
			}
		});
		
		_reqnetw_request_listener = new RequestNetwork.RequestListener() {
			@Override
			public void onResponse(String _param1, String _param2, HashMap<String, Object> _param3) {
				final String _tag = _param1;
				final String _response = _param2;
				final HashMap<String, Object> _responseHeaders = _param3;
				if (_tag.equals("DELETE")) {
					SketchwareUtil.showMessage(getApplicationContext(), _response);
					intent.setClass(getApplicationContext(), KelolauserActivity.class);
					startActivity(intent);
					finish();
				}
				if (_tag.equals("UPDATE")) {
					SketchwareUtil.showMessage(getApplicationContext(), _response);
					intent.setClass(getApplicationContext(), KelolauserActivity.class);
					startActivity(intent);
					finish();
				}
				if (_tag.equals("GETLEVEL")) {
					if (_response.equals("")) {
						SketchwareUtil.showMessage(getApplicationContext(), _response);
					}
					else {
						listmaplevel = new Gson().fromJson(_response, new TypeToken<ArrayList<HashMap<String, Object>>>(){}.getType());
						jml = listmaplevel.size();
						awal = 0;
						for(int _repeat92 = 0; _repeat92 < (int)(jml); _repeat92++) {
							strlevel.add(listmaplevel.get((int)awal).get("level").toString());
							awal++;
						}
						spinner1.setAdapter(new ArrayAdapter<String>(getBaseContext(), android.R.layout.simple_spinner_dropdown_item, strlevel));
						spinner1.setSelection((int)(Double.parseDouble(getIntent().getStringExtra("id_level")) - 1));
						((ArrayAdapter)spinner1.getAdapter()).notifyDataSetChanged();
					}
				}
			}
			
			@Override
			public void onErrorResponse(String _param1, String _param2) {
				final String _tag = _param1;
				final String _message = _param2;
				SketchwareUtil.showMessage(getApplicationContext(), _message);
			}
		};
	}
	
	private void initializeLogic() {
		setTitle("Edit User");
		reqnetw.startRequestNetwork(RequestNetworkController.POST, fileconfig.getString("server", "").concat("tampil_level"), "GETLEVEL", _reqnetw_request_listener);
	}
	
	@Override
	protected void onActivityResult(int _requestCode, int _resultCode, Intent _data) {
		
		super.onActivityResult(_requestCode, _resultCode, _data);
		
		switch (_requestCode) {
			
			default:
			break;
		}
	}
	
	@Override
	public void onBackPressed() {
		intent.putExtra("nama_user", getIntent().getStringExtra("nama_user"));
		intent.putExtra("server", getIntent().getStringExtra("server"));
		intent.setClass(getApplicationContext(), KelolauserActivity.class);
		startActivity(intent);
		finish();
	}
	
	@Override
	public void onStart() {
		super.onStart();
		edittext1.setText(getIntent().getStringExtra("username"));
		edittext2.setText(getIntent().getStringExtra("nama_user"));
	}
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input){
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels(){
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels(){
		return getResources().getDisplayMetrics().heightPixels;
	}
	
}
