package com.rpl.smkn2kng.absensi.dadan;

import androidx.appcompat.app.AppCompatActivity;
import androidx.annotation.*;
import androidx.appcompat.widget.Toolbar;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import com.google.android.material.appbar.AppBarLayout;
import android.app.*;
import android.os.*;
import android.view.*;
import android.view.View.*;
import android.widget.*;
import android.content.*;
import android.content.res.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.text.*;
import android.text.style.*;
import android.util.*;
import android.webkit.*;
import android.animation.*;
import android.view.animation.*;
import java.util.*;
import java.util.regex.*;
import java.text.*;
import org.json.*;
import java.util.HashMap;
import java.util.ArrayList;
import android.widget.ScrollView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.ArrayAdapter;
import android.content.Intent;
import android.net.Uri;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.app.Activity;
import android.content.SharedPreferences;
import android.view.View;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.DialogFragment;


public class DetailgurupiketActivity extends  AppCompatActivity  { 
	
	
	private Toolbar _toolbar;
	private AppBarLayout _app_bar;
	private CoordinatorLayout _coordinator;
	private HashMap<String, Object> mappostdata = new HashMap<>();
	private HashMap<String, Object> maphapus = new HashMap<>();
	private double num1 = 0;
	private double awal = 0;
	private double jml = 0;
	private double jml2 = 0;
	private double awal2 = 0;
	
	private ArrayList<String> strlisthari = new ArrayList<>();
	private ArrayList<HashMap<String, Object>> list_map_jam1 = new ArrayList<>();
	private ArrayList<String> strlist_jam1 = new ArrayList<>();
	private ArrayList<String> strlist_jam2 = new ArrayList<>();
	private ArrayList<HashMap<String, Object>> list_map_jam2 = new ArrayList<>();
	
	private ScrollView vscroll1;
	private LinearLayout linear1;
	private LinearLayout linear3;
	private LinearLayout linear7;
	private LinearLayout linear4;
	private LinearLayout linear5;
	private LinearLayout linear6;
	private LinearLayout linear2;
	private TextView textview2;
	private TextView textview3;
	private TextView textview4;
	private TextView textview5;
	private TextView textview6;
	private TextView textview7;
	private Button button4;
	private Button button2;
	private Button button3;
	private EditText edittext1;
	private EditText edittext2;
	private LinearLayout linear9;
	private LinearLayout linear10;
	private LinearLayout linear8;
	private TextView textview9;
	private Spinner spinner1;
	private TextView textview10;
	private Spinner spinner2;
	private TextView textview11;
	private Spinner spinner3;
	private Button button1;
	private Button button5;
	
	private RequestNetwork reqnetw;
	private RequestNetwork.RequestListener _reqnetw_request_listener;
	private Intent intent = new Intent();
	private AlertDialog.Builder dialog;
	private SharedPreferences fileconfig;
	private RequestNetwork reqnetwjam1;
	private RequestNetwork.RequestListener _reqnetwjam1_request_listener;
	private RequestNetwork reqnetwjam2;
	private RequestNetwork.RequestListener _reqnetwjam2_request_listener;
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.detailgurupiket);
		initialize(_savedInstanceState);
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		
		_app_bar = (AppBarLayout) findViewById(R.id._app_bar);
		_coordinator = (CoordinatorLayout) findViewById(R.id._coordinator);
		_toolbar = (Toolbar) findViewById(R.id._toolbar);
		setSupportActionBar(_toolbar);
		getSupportActionBar().setDisplayHomeAsUpEnabled(true);
		getSupportActionBar().setHomeButtonEnabled(true);
		_toolbar.setNavigationOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _v) {
				onBackPressed();
			}
		});
		vscroll1 = (ScrollView) findViewById(R.id.vscroll1);
		linear1 = (LinearLayout) findViewById(R.id.linear1);
		linear3 = (LinearLayout) findViewById(R.id.linear3);
		linear7 = (LinearLayout) findViewById(R.id.linear7);
		linear4 = (LinearLayout) findViewById(R.id.linear4);
		linear5 = (LinearLayout) findViewById(R.id.linear5);
		linear6 = (LinearLayout) findViewById(R.id.linear6);
		linear2 = (LinearLayout) findViewById(R.id.linear2);
		textview2 = (TextView) findViewById(R.id.textview2);
		textview3 = (TextView) findViewById(R.id.textview3);
		textview4 = (TextView) findViewById(R.id.textview4);
		textview5 = (TextView) findViewById(R.id.textview5);
		textview6 = (TextView) findViewById(R.id.textview6);
		textview7 = (TextView) findViewById(R.id.textview7);
		button4 = (Button) findViewById(R.id.button4);
		button2 = (Button) findViewById(R.id.button2);
		button3 = (Button) findViewById(R.id.button3);
		edittext1 = (EditText) findViewById(R.id.edittext1);
		edittext2 = (EditText) findViewById(R.id.edittext2);
		linear9 = (LinearLayout) findViewById(R.id.linear9);
		linear10 = (LinearLayout) findViewById(R.id.linear10);
		linear8 = (LinearLayout) findViewById(R.id.linear8);
		textview9 = (TextView) findViewById(R.id.textview9);
		spinner1 = (Spinner) findViewById(R.id.spinner1);
		textview10 = (TextView) findViewById(R.id.textview10);
		spinner2 = (Spinner) findViewById(R.id.spinner2);
		textview11 = (TextView) findViewById(R.id.textview11);
		spinner3 = (Spinner) findViewById(R.id.spinner3);
		button1 = (Button) findViewById(R.id.button1);
		button5 = (Button) findViewById(R.id.button5);
		reqnetw = new RequestNetwork(this);
		dialog = new AlertDialog.Builder(this);
		fileconfig = getSharedPreferences("fileconfig", Activity.MODE_PRIVATE);
		reqnetwjam1 = new RequestNetwork(this);
		reqnetwjam2 = new RequestNetwork(this);
		
		button4.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				setTitle("Update Data");
				linear7.setVisibility(View.VISIBLE);
				linear3.setVisibility(View.GONE);
			}
		});
		
		button2.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				maphapus = new HashMap<>();
				dialog.setTitle("Hapus Data");
				maphapus.put("nip", textview3.getText().toString());
				dialog.setMessage("Hapus data ini?");
				dialog.setPositiveButton("Ya", new DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface _dialog, int _which) {
						reqnetw.setParams(maphapus, RequestNetworkController.REQUEST_PARAM);
						reqnetw.startRequestNetwork(RequestNetworkController.POST, fileconfig.getString("server", "").concat("hapus_guru_piket"), "DELETE", _reqnetw_request_listener);
					}
				});
				dialog.setNegativeButton("Tidak", new DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface _dialog, int _which) {
						
					}
				});
				dialog.create().show();
			}
		});
		
		button3.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				intent.setClass(getApplicationContext(), KelolagurupiketActivity.class);
				startActivity(intent);
				finish();
			}
		});
		
		button1.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				mappostdata = new HashMap<>();
				mappostdata.put("nip", edittext1.getText().toString());
				mappostdata.put("nama_guru", edittext2.getText().toString());
				mappostdata.put("hari", strlisthari.get((int)(spinner1.getSelectedItemPosition())));
				mappostdata.put("jam_piket1", strlist_jam1.get((int)(spinner2.getSelectedItemPosition())));
				mappostdata.put("jam_piket2", strlist_jam2.get((int)(spinner3.getSelectedItemPosition())));
				dialog.setTitle("Update Data");
				dialog.setMessage("Are you sure to update this data?");
				dialog.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface _dialog, int _which) {
						reqnetw.setParams(mappostdata, RequestNetworkController.REQUEST_PARAM);
						reqnetw.startRequestNetwork(RequestNetworkController.POST, fileconfig.getString("server", "").concat("update_guru_piket"), "UPDATE", _reqnetw_request_listener);
					}
				});
				dialog.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface _dialog, int _which) {
						
					}
				});
				dialog.create().show();
			}
		});
		
		button5.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				setTitle("Detail Data");
				linear7.setVisibility(View.GONE);
				linear3.setVisibility(View.VISIBLE);
			}
		});
		
		_reqnetw_request_listener = new RequestNetwork.RequestListener() {
			@Override
			public void onResponse(String _param1, String _param2, HashMap<String, Object> _param3) {
				final String _tag = _param1;
				final String _response = _param2;
				final HashMap<String, Object> _responseHeaders = _param3;
				SketchwareUtil.showMessage(getApplicationContext(), _response);
				intent.setClass(getApplicationContext(), KelolagurupiketActivity.class);
				startActivity(intent);
				finish();
			}
			
			@Override
			public void onErrorResponse(String _param1, String _param2) {
				final String _tag = _param1;
				final String _message = _param2;
				SketchwareUtil.showMessage(getApplicationContext(), _message);
				intent.setClass(getApplicationContext(), KelolagurupiketActivity.class);
				startActivity(intent);
				finish();
			}
		};
		
		_reqnetwjam1_request_listener = new RequestNetwork.RequestListener() {
			@Override
			public void onResponse(String _param1, String _param2, HashMap<String, Object> _param3) {
				final String _tag = _param1;
				final String _response = _param2;
				final HashMap<String, Object> _responseHeaders = _param3;
				if (_tag.equals("GETJAM1")) {
					if (_response.equals("")) {
						SketchwareUtil.showMessage(getApplicationContext(), _response);
					}
					else {
						list_map_jam1 = new Gson().fromJson(_response, new TypeToken<ArrayList<HashMap<String, Object>>>(){}.getType());
						jml = list_map_jam1.size();
						awal = 0;
						for(int _repeat23 = 0; _repeat23 < (int)(jml); _repeat23++) {
							strlist_jam1.add(list_map_jam1.get((int)awal).get("jam_piket").toString());
							awal++;
						}
						spinner2.setAdapter(new ArrayAdapter<String>(getBaseContext(), android.R.layout.simple_spinner_dropdown_item, strlist_jam1));
						spinner2.setSelection((int)(Double.parseDouble(getIntent().getStringExtra("jam_piket").substring((int)(7), (int)(8))) - 1));
					}
				}
			}
			
			@Override
			public void onErrorResponse(String _param1, String _param2) {
				final String _tag = _param1;
				final String _message = _param2;
				SketchwareUtil.showMessage(getApplicationContext(), _message);
			}
		};
		
		_reqnetwjam2_request_listener = new RequestNetwork.RequestListener() {
			@Override
			public void onResponse(String _param1, String _param2, HashMap<String, Object> _param3) {
				final String _tag = _param1;
				final String _response = _param2;
				final HashMap<String, Object> _responseHeaders = _param3;
				if (_tag.equals("GETJAM2")) {
					if (_response.equals("")) {
						SketchwareUtil.showMessage(getApplicationContext(), _response);
					}
					else {
						list_map_jam2 = new Gson().fromJson(_response, new TypeToken<ArrayList<HashMap<String, Object>>>(){}.getType());
						jml2 = list_map_jam2.size();
						awal2 = 0;
						for(int _repeat44 = 0; _repeat44 < (int)(jml2); _repeat44++) {
							strlist_jam2.add(list_map_jam2.get((int)awal2).get("jam_piket").toString());
							awal2++;
						}
						spinner3.setAdapter(new ArrayAdapter<String>(getBaseContext(), android.R.layout.simple_spinner_dropdown_item, strlist_jam2));
						spinner3.setSelection((int)(Double.parseDouble(getIntent().getStringExtra("jam_piket").substring((int)(23), (int)(24))) - 1));
					}
				}
			}
			
			@Override
			public void onErrorResponse(String _param1, String _param2) {
				final String _tag = _param1;
				final String _message = _param2;
				SketchwareUtil.showMessage(getApplicationContext(), _message);
			}
		};
	}
	
	private void initializeLogic() {
		setTitle("Detail Guru Piket");
		reqnetwjam1.startRequestNetwork(RequestNetworkController.POST, fileconfig.getString("server", "").concat("tampil_jadwal_piket"), "GETJAM1", _reqnetwjam1_request_listener);
		reqnetwjam2.startRequestNetwork(RequestNetworkController.POST, fileconfig.getString("server", "").concat("tampil_jadwal_piket"), "GETJAM2", _reqnetwjam2_request_listener);
		strlisthari.add("Senin");
		strlisthari.add("Selasa");
		strlisthari.add("Rabu");
		strlisthari.add("Kamis");
		strlisthari.add("Jum'at");
		spinner1.setAdapter(new ArrayAdapter<String>(getBaseContext(), android.R.layout.simple_spinner_dropdown_item, strlisthari));
		((ArrayAdapter)spinner1.getAdapter()).notifyDataSetChanged();
		linear7.setVisibility(View.GONE);
	}
	
	@Override
	protected void onActivityResult(int _requestCode, int _resultCode, Intent _data) {
		
		super.onActivityResult(_requestCode, _resultCode, _data);
		
		switch (_requestCode) {
			
			default:
			break;
		}
	}
	
	@Override
	public void onBackPressed() {
		intent.setClass(getApplicationContext(), KelolagurupiketActivity.class);
		startActivity(intent);
		finish();
	}
	
	@Override
	public void onStart() {
		super.onStart();
		textview3.setText(getIntent().getStringExtra("nip"));
		textview5.setText(getIntent().getStringExtra("nama_guru"));
		textview7.setText(getIntent().getStringExtra("hari").concat(", ".concat(getIntent().getStringExtra("jam_piket"))));
		edittext1.setText(getIntent().getStringExtra("nip"));
		edittext2.setText(getIntent().getStringExtra("nama_guru"));
		if (getIntent().getStringExtra("hari").equals("Senin")) {
			spinner1.setSelection((int)(0));
		}
		if (getIntent().getStringExtra("hari").equals("Selasa")) {
			spinner1.setSelection((int)(1));
		}
		if (getIntent().getStringExtra("hari").equals("Rabu")) {
			spinner1.setSelection((int)(2));
		}
		if (getIntent().getStringExtra("hari").equals("Kamis")) {
			spinner1.setSelection((int)(3));
		}
		if (getIntent().getStringExtra("hari").equals("Jum'at")) {
			spinner1.setSelection((int)(4));
		}
	}
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input){
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels(){
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels(){
		return getResources().getDisplayMetrics().heightPixels;
	}
	
}
