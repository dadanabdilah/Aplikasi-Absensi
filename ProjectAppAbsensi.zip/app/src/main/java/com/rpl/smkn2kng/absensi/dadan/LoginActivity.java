package com.rpl.smkn2kng.absensi.dadan;

import androidx.appcompat.app.AppCompatActivity;
import androidx.annotation.*;
import android.app.*;
import android.os.*;
import android.view.*;
import android.view.View.*;
import android.widget.*;
import android.content.*;
import android.content.res.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.text.*;
import android.text.style.*;
import android.util.*;
import android.webkit.*;
import android.animation.*;
import android.view.animation.*;
import java.util.*;
import java.util.regex.*;
import java.text.*;
import org.json.*;
import java.util.HashMap;
import java.util.ArrayList;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.EditText;
import android.content.Intent;
import android.net.Uri;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.app.Activity;
import android.content.SharedPreferences;
import android.view.View;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.DialogFragment;


public class LoginActivity extends  AppCompatActivity  { 
	
	
	private HashMap<String, Object> mapdatalogin = new HashMap<>();
	private HashMap<String, Object> maphasil = new HashMap<>();
	
	private ArrayList<HashMap<String, Object>> listmap = new ArrayList<>();
	
	private LinearLayout linear1;
	private LinearLayout linear5;
	private LinearLayout linear2;
	private LinearLayout linear3;
	private TextView textview2;
	private Button button1;
	private ImageView imageview1;
	private EditText edittext1;
	private ImageView imageview2;
	private EditText edittext2;
	
	private Intent intent = new Intent();
	private RequestNetwork reqnetw;
	private RequestNetwork.RequestListener _reqnetw_request_listener;
	private AlertDialog.Builder dialog;
	private SharedPreferences fileconfig;
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.login);
		initialize(_savedInstanceState);
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		
		linear1 = (LinearLayout) findViewById(R.id.linear1);
		linear5 = (LinearLayout) findViewById(R.id.linear5);
		linear2 = (LinearLayout) findViewById(R.id.linear2);
		linear3 = (LinearLayout) findViewById(R.id.linear3);
		textview2 = (TextView) findViewById(R.id.textview2);
		button1 = (Button) findViewById(R.id.button1);
		imageview1 = (ImageView) findViewById(R.id.imageview1);
		edittext1 = (EditText) findViewById(R.id.edittext1);
		imageview2 = (ImageView) findViewById(R.id.imageview2);
		edittext2 = (EditText) findViewById(R.id.edittext2);
		reqnetw = new RequestNetwork(this);
		dialog = new AlertDialog.Builder(this);
		fileconfig = getSharedPreferences("fileconfig", Activity.MODE_PRIVATE);
		
		button1.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				mapdatalogin = new HashMap<>();
				mapdatalogin.put("username", edittext1.getText().toString());
				mapdatalogin.put("password", edittext2.getText().toString());
				reqnetw.setParams(mapdatalogin, RequestNetworkController.REQUEST_PARAM);
				reqnetw.startRequestNetwork(RequestNetworkController.POST, fileconfig.getString("server", "").concat("login"), "CECKDATA", _reqnetw_request_listener);
			}
		});
		
		_reqnetw_request_listener = new RequestNetwork.RequestListener() {
			@Override
			public void onResponse(String _param1, String _param2, HashMap<String, Object> _param3) {
				final String _tag = _param1;
				final String _response = _param2;
				final HashMap<String, Object> _responseHeaders = _param3;
				maphasil = new Gson().fromJson(_response, new TypeToken<HashMap<String, Object>>(){}.getType());
				if (maphasil.get("status").toString().equals("loggedin")) {
					if (maphasil.get("level").toString().equals("Admin")) {
						fileconfig.edit().putString("nama_user", maphasil.get("nama_user").toString()).commit();
						fileconfig.edit().putString("username", maphasil.get("username").toString()).commit();
						intent.setClass(getApplicationContext(), AdminActivity.class);
						startActivity(intent);
						finish();
					}
					if (maphasil.get("level").toString().equals("Piket")) {
						fileconfig.edit().putString("nama_user", maphasil.get("nama_user").toString()).commit();
						fileconfig.edit().putString("username", maphasil.get("username").toString()).commit();
						intent.setClass(getApplicationContext(), PiketActivity.class);
						startActivity(intent);
						finish();
					}
					if (maphasil.get("level").toString().equals("Siswa")) {
						fileconfig.edit().putString("nama_user", maphasil.get("nama_user").toString()).commit();
						fileconfig.edit().putString("username", maphasil.get("username").toString()).commit();
						intent.setClass(getApplicationContext(), SiswaActivity.class);
						startActivity(intent);
						finish();
					}
					if (maphasil.get("level").toString().equals("Sekertaris")) {
						fileconfig.edit().putString("nama_user", maphasil.get("nama_user").toString()).commit();
						fileconfig.edit().putString("username", maphasil.get("username").toString()).commit();
						intent.setClass(getApplicationContext(), SekertarisActivity.class);
						startActivity(intent);
						finish();
					}
				}
				else {
					dialog.setMessage(maphasil.get("pesan").toString());
					dialog.setPositiveButton("Close", new DialogInterface.OnClickListener() {
						@Override
						public void onClick(DialogInterface _dialog, int _which) {
							
						}
					});
					dialog.create().show();
				}
			}
			
			@Override
			public void onErrorResponse(String _param1, String _param2) {
				final String _tag = _param1;
				final String _message = _param2;
				SketchwareUtil.showMessage(getApplicationContext(), "Aktifkan jaringan internet anda!");
			}
		};
	}
	
	private void initializeLogic() {
		_borderwithround(linear5, 255, 255, 255, 3, "#EEEEEE", 10);
		_borderwithround(linear2, 255, 255, 255, 1, "#323232", 10);
		_borderwithround(linear3, 255, 255, 255, 1, "#323232", 10);
	}
	
	@Override
	protected void onActivityResult(int _requestCode, int _resultCode, Intent _data) {
		
		super.onActivityResult(_requestCode, _resultCode, _data);
		
		switch (_requestCode) {
			
			default:
			break;
		}
	}
	
	public void _borderwithround (final View _v, final double _col1, final double _col2, final double _col3, final double _width, final String _color, final double _r) {
		try{
			int[] colors = {Color.rgb((int) _col1,(int) _col2,(int)_col3),Color.rgb((int) _col1,(int) _col2,(int)_col3)};
			android.graphics.drawable.GradientDrawable gd = new android.graphics.drawable.GradientDrawable(android.graphics.drawable.GradientDrawable.Orientation.BR_TL, colors);
			gd.setCornerRadius((float)_r); 
			gd.setStroke((int)_width, (Color.parseColor(_color)));
			_v.setBackground(gd);
			
		}catch(Exception e) { showMessage(e.toString());}
	}
	
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input){
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels(){
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels(){
		return getResources().getDisplayMetrics().heightPixels;
	}
	
}
