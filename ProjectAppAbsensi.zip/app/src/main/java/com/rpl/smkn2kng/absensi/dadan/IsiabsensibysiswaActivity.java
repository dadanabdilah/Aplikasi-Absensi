package com.rpl.smkn2kng.absensi.dadan;

import androidx.appcompat.app.AppCompatActivity;
import androidx.annotation.*;
import androidx.appcompat.widget.Toolbar;
import android.app.*;
import android.os.*;
import android.view.*;
import android.view.View.*;
import android.widget.*;
import android.content.*;
import android.graphics.*;
import android.media.*;
import android.net.*;
import android.text.*;
import android.util.*;
import android.webkit.*;
import android.animation.*;
import android.view.animation.*;
import java.util.*;
import java.text.*;
import java.util.HashMap;
import java.util.ArrayList;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.ArrayAdapter;
import android.content.Intent;
import android.net.Uri;
import android.app.Activity;
import android.content.SharedPreferences;
import android.view.View;

public class IsiabsensibysiswaActivity extends AppCompatActivity {
	
	
	private Toolbar _toolbar;
	private HashMap<String, Object> mappostdata = new HashMap<>();
	
	private ArrayList<String> strlistwaktu = new ArrayList<>();
	private ArrayList<String> strlistkehadiran = new ArrayList<>();
	
	private LinearLayout linear1;
	private TextView textview5;
	private LinearLayout linear2;
	private LinearLayout linear4;
	private LinearLayout linear5;
	private Button button1;
	private TextView textview1;
	private EditText edittext1;
	private TextView textview3;
	private Spinner spinner2;
	private TextView textview4;
	private EditText edittext2;
	
	private RequestNetwork reqnetw;
	private RequestNetwork.RequestListener _reqnetw_request_listener;
	private Intent intent = new Intent();
	private SharedPreferences fileconfig;
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.isiabsensibysiswa);
		initialize(_savedInstanceState);
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		
		_toolbar = (Toolbar) findViewById(R.id._toolbar);
		setSupportActionBar(_toolbar);
		getSupportActionBar().setDisplayHomeAsUpEnabled(true);
		getSupportActionBar().setHomeButtonEnabled(true);
		_toolbar.setNavigationOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _v) {
				onBackPressed();
			}
		});
		linear1 = (LinearLayout) findViewById(R.id.linear1);
		textview5 = (TextView) findViewById(R.id.textview5);
		linear2 = (LinearLayout) findViewById(R.id.linear2);
		linear4 = (LinearLayout) findViewById(R.id.linear4);
		linear5 = (LinearLayout) findViewById(R.id.linear5);
		button1 = (Button) findViewById(R.id.button1);
		textview1 = (TextView) findViewById(R.id.textview1);
		edittext1 = (EditText) findViewById(R.id.edittext1);
		textview3 = (TextView) findViewById(R.id.textview3);
		spinner2 = (Spinner) findViewById(R.id.spinner2);
		textview4 = (TextView) findViewById(R.id.textview4);
		edittext2 = (EditText) findViewById(R.id.edittext2);
		reqnetw = new RequestNetwork(this);
		fileconfig = getSharedPreferences("fileconfig", Activity.MODE_PRIVATE);
		
		button1.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				mappostdata = new HashMap<>();
				mappostdata.put("nis", edittext1.getText().toString());
				mappostdata.put("waktu_absensi", getIntent().getStringExtra("waktu_absensi"));
				mappostdata.put("kehadiran", strlistkehadiran.get((int)(spinner2.getSelectedItemPosition())));
				mappostdata.put("keterangan", edittext2.getText().toString());
				reqnetw.setParams(mappostdata, RequestNetworkController.REQUEST_PARAM);
				reqnetw.startRequestNetwork(RequestNetworkController.POST, fileconfig.getString("server", "").concat("isi_absensi"), "SAVEDATA", _reqnetw_request_listener);
			}
		});
		
		_reqnetw_request_listener = new RequestNetwork.RequestListener() {
			@Override
			public void onResponse(String _param1, String _param2) {
				final String _tag = _param1;
				final String _response = _param2;
				SketchwareUtil.showMessage(getApplicationContext(), _response);
				intent.setClass(getApplicationContext(), SiswaActivity.class);
				startActivity(intent);
				finish();
			}
			
			@Override
			public void onErrorResponse(String _param1, String _param2) {
				final String _tag = _param1;
				final String _message = _param2;
				SketchwareUtil.showMessage(getApplicationContext(), _message);
			}
		};
	}
	private void initializeLogic() {
		textview5.setText("Isi Absensi ".concat(getIntent().getStringExtra("waktu_absensi")));
		edittext1.setText(fileconfig.getString("username", ""));
		strlistkehadiran.add("Alfa");
		strlistkehadiran.add("Hadir");
		strlistkehadiran.add("Izin");
		strlistkehadiran.add("Sakit");
		spinner2.setAdapter(new ArrayAdapter<String>(getBaseContext(), android.R.layout.simple_spinner_dropdown_item, strlistkehadiran));
		((ArrayAdapter)spinner2.getAdapter()).notifyDataSetChanged();
	}
	
	@Override
	protected void onActivityResult(int _requestCode, int _resultCode, Intent _data) {
		super.onActivityResult(_requestCode, _resultCode, _data);
		
		switch (_requestCode) {
			
			default:
			break;
		}
	}
	
	@Override
	public void onBackPressed() {
		intent.setClass(getApplicationContext(), SiswaActivity.class);
		startActivity(intent);
		finish();
	}
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input){
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels(){
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels(){
		return getResources().getDisplayMetrics().heightPixels;
	}
	
}
