package com.rpl.smkn2kng.absensi.dadan;

import androidx.appcompat.app.AppCompatActivity;
import androidx.annotation.*;
import androidx.appcompat.widget.Toolbar;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import com.google.android.material.appbar.AppBarLayout;
import android.app.*;
import android.os.*;
import android.view.*;
import android.view.View.*;
import android.widget.*;
import android.content.*;
import android.content.res.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.text.*;
import android.text.style.*;
import android.util.*;
import android.webkit.*;
import android.animation.*;
import android.view.animation.*;
import java.util.*;
import java.util.regex.*;
import java.text.*;
import org.json.*;
import java.util.HashMap;
import java.util.ArrayList;
import android.widget.ScrollView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.Button;
import android.content.Intent;
import android.net.Uri;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.app.Activity;
import android.content.SharedPreferences;
import android.view.View;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.DialogFragment;


public class UpdateprofilesiswaActivity extends  AppCompatActivity  { 
	
	
	private Toolbar _toolbar;
	private AppBarLayout _app_bar;
	private CoordinatorLayout _coordinator;
	private HashMap<String, Object> listmapkelas = new HashMap<>();
	private HashMap<String, Object> mapkelas = new HashMap<>();
	private double jml = 0;
	private double awal = 0;
	private String date = "";
	private HashMap<String, Object> mappostdata = new HashMap<>();
	
	private ArrayList<String> strlistjk = new ArrayList<>();
	private ArrayList<String> strlistkelas = new ArrayList<>();
	private ArrayList<HashMap<String, Object>> listmap = new ArrayList<>();
	
	private ScrollView vscroll2;
	private LinearLayout linear12;
	private LinearLayout linear5;
	private LinearLayout linear6;
	private LinearLayout linear15;
	private LinearLayout linear16;
	private LinearLayout linear9;
	private LinearLayout linear10;
	private LinearLayout linear13;
	private LinearLayout linear14;
	private TextView textview10;
	private TextView textview11;
	private TextView textview12;
	private EditText edittext1;
	private TextView textview26;
	private Spinner spinner1;
	private TextView textview27;
	private EditText edittext2;
	private ImageView imageview1;
	private TextView textview18;
	private EditText edittext6;
	private TextView textview20;
	private EditText edittext7;
	private TextView textview25;
	private Spinner spinner2;
	private Button button1;
	
	private RequestNetwork reqnetw;
	private RequestNetwork.RequestListener _reqnetw_request_listener;
	private Intent intent = new Intent();
	private RequestNetwork reqnetwkelas;
	private RequestNetwork.RequestListener _reqnetwkelas_request_listener;
	private AlertDialog.Builder dialog;
	private SharedPreferences fileconfig;
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.updateprofilesiswa);
		initialize(_savedInstanceState);
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		
		_app_bar = (AppBarLayout) findViewById(R.id._app_bar);
		_coordinator = (CoordinatorLayout) findViewById(R.id._coordinator);
		_toolbar = (Toolbar) findViewById(R.id._toolbar);
		setSupportActionBar(_toolbar);
		getSupportActionBar().setDisplayHomeAsUpEnabled(true);
		getSupportActionBar().setHomeButtonEnabled(true);
		_toolbar.setNavigationOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _v) {
				onBackPressed();
			}
		});
		vscroll2 = (ScrollView) findViewById(R.id.vscroll2);
		linear12 = (LinearLayout) findViewById(R.id.linear12);
		linear5 = (LinearLayout) findViewById(R.id.linear5);
		linear6 = (LinearLayout) findViewById(R.id.linear6);
		linear15 = (LinearLayout) findViewById(R.id.linear15);
		linear16 = (LinearLayout) findViewById(R.id.linear16);
		linear9 = (LinearLayout) findViewById(R.id.linear9);
		linear10 = (LinearLayout) findViewById(R.id.linear10);
		linear13 = (LinearLayout) findViewById(R.id.linear13);
		linear14 = (LinearLayout) findViewById(R.id.linear14);
		textview10 = (TextView) findViewById(R.id.textview10);
		textview11 = (TextView) findViewById(R.id.textview11);
		textview12 = (TextView) findViewById(R.id.textview12);
		edittext1 = (EditText) findViewById(R.id.edittext1);
		textview26 = (TextView) findViewById(R.id.textview26);
		spinner1 = (Spinner) findViewById(R.id.spinner1);
		textview27 = (TextView) findViewById(R.id.textview27);
		edittext2 = (EditText) findViewById(R.id.edittext2);
		imageview1 = (ImageView) findViewById(R.id.imageview1);
		textview18 = (TextView) findViewById(R.id.textview18);
		edittext6 = (EditText) findViewById(R.id.edittext6);
		textview20 = (TextView) findViewById(R.id.textview20);
		edittext7 = (EditText) findViewById(R.id.edittext7);
		textview25 = (TextView) findViewById(R.id.textview25);
		spinner2 = (Spinner) findViewById(R.id.spinner2);
		button1 = (Button) findViewById(R.id.button1);
		reqnetw = new RequestNetwork(this);
		reqnetwkelas = new RequestNetwork(this);
		dialog = new AlertDialog.Builder(this);
		fileconfig = getSharedPreferences("fileconfig", Activity.MODE_PRIVATE);
		
		imageview1.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				showDatePickerDialog(imageview1);
			}
		});
		
		button1.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				mappostdata = new HashMap<>();
				mappostdata.put("nis", textview11.getText().toString());
				mappostdata.put("nama_siswa", edittext1.getText().toString());
				mappostdata.put("jk", strlistjk.get((int)(spinner1.getSelectedItemPosition())));
				mappostdata.put("tanggal_lahir", edittext2.getText().toString());
				mappostdata.put("alamat", edittext6.getText().toString());
				mappostdata.put("no_hp", edittext7.getText().toString());
				mappostdata.put("id_kelas", String.valueOf((long)(spinner2.getSelectedItemPosition() + 1)));
				dialog.setTitle("Update Profile");
				dialog.setMessage("Update profile kamu?");
				dialog.setPositiveButton("Ya", new DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface _dialog, int _which) {
						reqnetw.setParams(mappostdata, RequestNetworkController.REQUEST_PARAM);
						reqnetw.startRequestNetwork(RequestNetworkController.POST, fileconfig.getString("server", "").concat("update_siswa"), "UPDATE", _reqnetw_request_listener);
					}
				});
				dialog.setNegativeButton("Tidak", new DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface _dialog, int _which) {
						
					}
				});
				dialog.create().show();
			}
		});
		
		_reqnetw_request_listener = new RequestNetwork.RequestListener() {
			@Override
			public void onResponse(String _param1, String _param2, HashMap<String, Object> _param3) {
				final String _tag = _param1;
				final String _response = _param2;
				final HashMap<String, Object> _responseHeaders = _param3;
				SketchwareUtil.showMessage(getApplicationContext(), _response);
				intent.setClass(getApplicationContext(), ProfilesiswaActivity.class);
				startActivity(intent);
				finish();
			}
			
			@Override
			public void onErrorResponse(String _param1, String _param2) {
				final String _tag = _param1;
				final String _message = _param2;
				SketchwareUtil.showMessage(getApplicationContext(), _message);
			}
		};
		
		_reqnetwkelas_request_listener = new RequestNetwork.RequestListener() {
			@Override
			public void onResponse(String _param1, String _param2, HashMap<String, Object> _param3) {
				final String _tag = _param1;
				final String _response = _param2;
				final HashMap<String, Object> _responseHeaders = _param3;
				if (_response.equals("")) {
					SketchwareUtil.showMessage(getApplicationContext(), "Server error!");
				}
				else {
					listmap = new Gson().fromJson(_response, new TypeToken<ArrayList<HashMap<String, Object>>>(){}.getType());
					jml = listmap.size();
					awal = 0;
					for(int _repeat66 = 0; _repeat66 < (int)(jml); _repeat66++) {
						strlistkelas.add(listmap.get((int)awal).get("kelas").toString());
						awal++;
					}
					spinner2.setAdapter(new ArrayAdapter<String>(getBaseContext(), android.R.layout.simple_spinner_dropdown_item, strlistkelas));
					spinner2.setSelection((int)(Double.parseDouble(getIntent().getStringExtra("id_kelas")) - 1));
					((ArrayAdapter)spinner2.getAdapter()).notifyDataSetChanged();
				}
			}
			
			@Override
			public void onErrorResponse(String _param1, String _param2) {
				final String _tag = _param1;
				final String _message = _param2;
				SketchwareUtil.showMessage(getApplicationContext(), _message);
			}
		};
	}
	
	private void initializeLogic() {
		setTitle("Edit Profil");
		strlistjk.add("L");
		strlistjk.add("P");
		spinner1.setAdapter(new ArrayAdapter<String>(getBaseContext(), android.R.layout.simple_spinner_dropdown_item, strlistjk));
		((ArrayAdapter)spinner1.getAdapter()).notifyDataSetChanged();
		textview11.setText(getIntent().getStringExtra("nis"));
		edittext1.setText(getIntent().getStringExtra("nama_siswa"));
		if (getIntent().getStringExtra("jk").equals("L")) {
			spinner1.setSelection((int)(0));
		}
		else {
			spinner1.setSelection((int)(1));
		}
		edittext2.setText(getIntent().getStringExtra("tanggal_lahir"));
		edittext6.setText(getIntent().getStringExtra("alamat"));
		edittext7.setText(getIntent().getStringExtra("no_hp"));
	}
	
	@Override
	protected void onActivityResult(int _requestCode, int _resultCode, Intent _data) {
		
		super.onActivityResult(_requestCode, _resultCode, _data);
		
		switch (_requestCode) {
			
			default:
			break;
		}
	}
	
	@Override
	public void onBackPressed() {
		intent.setClass(getApplicationContext(), ProfilesiswaActivity.class);
		startActivity(intent);
		finish();
	}
	
	@Override
	public void onStart() {
		super.onStart();
		reqnetwkelas.startRequestNetwork(RequestNetworkController.POST, fileconfig.getString("server", "").concat("tampil_kelas"), "GETKELAS", _reqnetwkelas_request_listener);
	}
	public void showDatePickerDialog(View v) {
		DialogFragment newFragment = new DatePickerFragment();
		newFragment.show(getSupportFragmentManager(), "datePicker");
	}
	public class DatePickerFragment extends DialogFragment implements DatePickerDialog.OnDateSetListener {
		@Override
		public Dialog onCreateDialog(Bundle savedInstanceState) {
			final Calendar c = Calendar.getInstance();
			int year = c.get(Calendar.YEAR);
			int month = c.get(Calendar.MONTH);
			int day = c.get(Calendar.DAY_OF_MONTH);
			return new DatePickerDialog(getActivity(), this, year, month, day);
		}
		public void onDateSet(DatePicker view, int year, int month, int day) {
			int mon = month +1;
			date = year+ "-" + mon + "-" + day;
			edittext2.setText(date);
		}
	}
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input){
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels(){
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels(){
		return getResources().getDisplayMetrics().heightPixels;
	}
	
}
