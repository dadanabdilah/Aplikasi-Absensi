package com.rpl.smkn2kng.absensi.dadan;

import androidx.appcompat.app.AppCompatActivity;
import androidx.annotation.*;
import androidx.appcompat.widget.Toolbar;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import com.google.android.material.appbar.AppBarLayout;
import android.app.*;
import android.os.*;
import android.view.*;
import android.view.View.*;
import android.widget.*;
import android.content.*;
import android.content.res.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.text.*;
import android.text.style.*;
import android.util.*;
import android.webkit.*;
import android.animation.*;
import android.view.animation.*;
import java.util.*;
import java.util.regex.*;
import java.text.*;
import org.json.*;
import java.util.HashMap;
import java.util.ArrayList;
import android.widget.ScrollView;
import android.widget.LinearLayout;
import android.widget.EditText;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Spinner;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.content.Intent;
import android.net.Uri;
import android.app.Activity;
import android.content.SharedPreferences;
import android.view.View;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.DialogFragment;


public class TambahsiswaActivity extends  AppCompatActivity  { 
	
	
	private Toolbar _toolbar;
	private AppBarLayout _app_bar;
	private CoordinatorLayout _coordinator;
	private double jml = 0;
	private double awal = 0;
	private String date = "";
	private HashMap<String, Object> mappostdata = new HashMap<>();
	
	private ArrayList<String> liststrjk = new ArrayList<>();
	private ArrayList<HashMap<String, Object>> listmapkelas = new ArrayList<>();
	private ArrayList<String> liststrkelas = new ArrayList<>();
	
	private ScrollView vscroll1;
	private LinearLayout linear4;
	private EditText edittext1;
	private EditText edittext2;
	private LinearLayout linear5;
	private LinearLayout linear6;
	private EditText edittext4;
	private EditText edittext5;
	private LinearLayout linear7;
	private Button button1;
	private TextView textview3;
	private Spinner spinner1;
	private TextView textview4;
	private EditText edittext3;
	private ImageView imageview1;
	private TextView textview5;
	private Spinner spinner2;
	
	private Intent intent = new Intent();
	private RequestNetwork reqnetw;
	private RequestNetwork.RequestListener _reqnetw_request_listener;
	private SharedPreferences fileconfig;
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.tambahsiswa);
		initialize(_savedInstanceState);
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		
		_app_bar = (AppBarLayout) findViewById(R.id._app_bar);
		_coordinator = (CoordinatorLayout) findViewById(R.id._coordinator);
		_toolbar = (Toolbar) findViewById(R.id._toolbar);
		setSupportActionBar(_toolbar);
		getSupportActionBar().setDisplayHomeAsUpEnabled(true);
		getSupportActionBar().setHomeButtonEnabled(true);
		_toolbar.setNavigationOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _v) {
				onBackPressed();
			}
		});
		vscroll1 = (ScrollView) findViewById(R.id.vscroll1);
		linear4 = (LinearLayout) findViewById(R.id.linear4);
		edittext1 = (EditText) findViewById(R.id.edittext1);
		edittext2 = (EditText) findViewById(R.id.edittext2);
		linear5 = (LinearLayout) findViewById(R.id.linear5);
		linear6 = (LinearLayout) findViewById(R.id.linear6);
		edittext4 = (EditText) findViewById(R.id.edittext4);
		edittext5 = (EditText) findViewById(R.id.edittext5);
		linear7 = (LinearLayout) findViewById(R.id.linear7);
		button1 = (Button) findViewById(R.id.button1);
		textview3 = (TextView) findViewById(R.id.textview3);
		spinner1 = (Spinner) findViewById(R.id.spinner1);
		textview4 = (TextView) findViewById(R.id.textview4);
		edittext3 = (EditText) findViewById(R.id.edittext3);
		imageview1 = (ImageView) findViewById(R.id.imageview1);
		textview5 = (TextView) findViewById(R.id.textview5);
		spinner2 = (Spinner) findViewById(R.id.spinner2);
		reqnetw = new RequestNetwork(this);
		fileconfig = getSharedPreferences("fileconfig", Activity.MODE_PRIVATE);
		
		button1.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				mappostdata = new HashMap<>();
				mappostdata.put("nis", edittext1.getText().toString());
				mappostdata.put("nama_siswa", edittext2.getText().toString());
				mappostdata.put("jk", liststrjk.get((int)(spinner1.getSelectedItemPosition())));
				mappostdata.put("tanggal_lahir", edittext3.getText().toString());
				mappostdata.put("alamat", edittext4.getText().toString());
				mappostdata.put("no_hp", edittext5.getText().toString());
				mappostdata.put("kelas", liststrkelas.get((int)(spinner2.getSelectedItemPosition())));
				reqnetw.setParams(mappostdata, RequestNetworkController.REQUEST_PARAM);
				reqnetw.startRequestNetwork(RequestNetworkController.POST, fileconfig.getString("server", "").concat("tambah_siswa"), "SAVEDATA", _reqnetw_request_listener);
			}
		});
		
		imageview1.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				showDatePickerDialog(imageview1);
			}
		});
		
		_reqnetw_request_listener = new RequestNetwork.RequestListener() {
			@Override
			public void onResponse(String _param1, String _param2, HashMap<String, Object> _param3) {
				final String _tag = _param1;
				final String _response = _param2;
				final HashMap<String, Object> _responseHeaders = _param3;
				if (_tag.equals("GETKELAS")) {
					if (_response.equals("")) {
						SketchwareUtil.showMessage(getApplicationContext(), _response);
					}
					else {
						listmapkelas = new Gson().fromJson(_response, new TypeToken<ArrayList<HashMap<String, Object>>>(){}.getType());
						jml = listmapkelas.size();
						awal = 0;
						for(int _repeat23 = 0; _repeat23 < (int)(jml); _repeat23++) {
							liststrkelas.add(listmapkelas.get((int)awal).get("kelas").toString());
							awal++;
						}
						spinner2.setAdapter(new ArrayAdapter<String>(getBaseContext(), android.R.layout.simple_spinner_dropdown_item, liststrkelas));
						((ArrayAdapter)spinner2.getAdapter()).notifyDataSetChanged();
					}
				}
				if (_tag.equals("SAVEDATA")) {
					SketchwareUtil.showMessage(getApplicationContext(), _response);
					intent.setClass(getApplicationContext(), KelolasiswaActivity.class);
					startActivity(intent);
					finish();
				}
			}
			
			@Override
			public void onErrorResponse(String _param1, String _param2) {
				final String _tag = _param1;
				final String _message = _param2;
				SketchwareUtil.showMessage(getApplicationContext(), _message);
			}
		};
	}
	
	private void initializeLogic() {
		setTitle("Tambah Data Siswa");
		liststrjk.add("L");
		liststrjk.add("P");
		spinner1.setAdapter(new ArrayAdapter<String>(getBaseContext(), android.R.layout.simple_spinner_dropdown_item, liststrjk));
		((ArrayAdapter)spinner1.getAdapter()).notifyDataSetChanged();
		reqnetw.startRequestNetwork(RequestNetworkController.POST, fileconfig.getString("server", "").concat("tampil_kelas"), "GETKELAS", _reqnetw_request_listener);
	}
	
	@Override
	protected void onActivityResult(int _requestCode, int _resultCode, Intent _data) {
		
		super.onActivityResult(_requestCode, _resultCode, _data);
		
		switch (_requestCode) {
			
			default:
			break;
		}
	}
	
	@Override
	public void onStart() {
		super.onStart();
	}
	public void showDatePickerDialog(View v) {
		DialogFragment newFragment = new DatePickerFragment();
		newFragment.show(getSupportFragmentManager(), "datePicker");
	}
	public class DatePickerFragment extends DialogFragment implements DatePickerDialog.OnDateSetListener {
		@Override
		public Dialog onCreateDialog(Bundle savedInstanceState) {
			final Calendar c = Calendar.getInstance();
			int year = c.get(Calendar.YEAR);
			int month = c.get(Calendar.MONTH);
			int day = c.get(Calendar.DAY_OF_MONTH);
			return new DatePickerDialog(getActivity(), this, year, month, day);
		}
		public void onDateSet(DatePicker view, int year, int month, int day) {
			int mon = month +1;
			date = year+ "-" + mon + "-" + day;
			edittext3.setText(date);
		}
	}
	
	@Override
	public void onBackPressed() {
		intent.setClass(getApplicationContext(), KelolasiswaActivity.class);
		startActivity(intent);
		finish();
	}
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input){
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels(){
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels(){
		return getResources().getDisplayMetrics().heightPixels;
	}
	
}
